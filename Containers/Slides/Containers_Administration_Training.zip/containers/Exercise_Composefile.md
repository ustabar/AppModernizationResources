# Exercise — writing a Compose file

Let's write a Compose file for the wordsmith app!

The code is at: https://github.com/jpetazzo/wordsmith
