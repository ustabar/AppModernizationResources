## Exercise — Ingress

- Add an ingress controller to a Kubernetes cluster

- Create an ingress resource for a web app on that cluster

- Challenge: accessing/exposing port 80

  (different methods depending on how the cluster was deployed)
