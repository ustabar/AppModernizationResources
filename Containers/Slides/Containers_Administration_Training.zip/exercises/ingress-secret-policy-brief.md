⚠️ BROKEN EXERCISE - DO NOT USE

## Exercise — Ingress Secret Policy

*Implement policy to limit impact of ingress controller vulnerabilities.*

(Mitigate e.g. CVE-2021-25742)

- Deploy an ingress controller and cert-manager

- Deploy a trivial web app secured with TLS

  (obtaining a cert with cert-manager + Let's Encrypt)

- Prevent ingress controller from reading arbitrary secrets

- Automatically grant selective access to TLS secrets, but not other secrets
