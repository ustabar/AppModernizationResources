## Exercise — Terraform Node Pools

- Write a Terraform configuration to deploy a cluster

- The cluster should have two node pools with autoscaling

- Deploy two apps, each using exclusively one node pool

- Bonus: deploy an app balanced across both node pools
