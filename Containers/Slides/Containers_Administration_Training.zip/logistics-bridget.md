## Intros

 - Hello! We are:

   - ✨ Bridget ([@bridgetkromhout](https://twitter.com/bridgetkromhout))

   - 🌟 Joe ([@joelaha](https://twitter.com/joelaha))

- The workshop will run from 13:30-16:45

- There will be a break from 15:00-15:15

- Feel free to interrupt for questions at any time

- *Especially when you see full screen container pictures!*

